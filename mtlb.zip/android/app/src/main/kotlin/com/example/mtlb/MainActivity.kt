package com.example.mtlb

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
